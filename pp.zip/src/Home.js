import React, { useState, useEffect } from "react";
import { ethers } from "ethers";
import constants from "./constants";

function Home() {
  const [currentAccount, setCurrentAccount] = useState("");
  const [contractInstance, setContractInstance] = useState(null);
  const [status, setStatus] = useState(false);
  const [isWinner, setIsWinner] = useState(false);

  useEffect(() => {
    // Load wallet & account info
    const loadBlockchainData = async () => {
      if (typeof window.ethereum === "undefined") {
        alert("Please install Metamask to use this application");
        return;
      }
      try {
        const provider = new ethers.BrowserProvider(window.ethereum);

        // Prompt user to connect accounts (if not already connected)
        await provider.send("eth_requestAccounts", []);

        // getSigner() is asynchronous in Ethers v6
        const signer = await provider.getSigner();

        // getAddress() is also async in v6
        const address = await signer.getAddress();
        console.log("Current account:", address);
        setCurrentAccount(address);

        // Listen for account changes in MetaMask
        window.ethereum.on("accountsChanged", (accounts) => {
          setCurrentAccount(accounts[0]);
        });
      } catch (err) {
        console.error("Error in loadBlockchainData:", err);
      }
    };

    // Load contract & call contract functions
    const loadContractData = async () => {
      if (typeof window.ethereum === "undefined") return;
      try {
        const provider = new ethers.BrowserProvider(window.ethereum);
        // Ensure we've requested accounts:
        await provider.send("eth_requestAccounts", []);
        const signer = await provider.getSigner();

        // Create a new contract instance
        const contractIns = new ethers.Contract(
          constants.contractAddress,
          constants.contractAbi,
          signer
        );

        // Call read-only functions from the local contractIns
        console.log("Manager:", await contractIns.getManager());
        console.log("Claimed:", await contractIns.claimed());

        const statusFromChain = await contractIns.isComplete();
        const winnerFromChain = await contractIns.getWinner();

        // Update state
        setContractInstance(contractIns);
        setStatus(statusFromChain);

        // Check if the current account is the winner
        if (winnerFromChain === currentAccount) {
          setIsWinner(true);
        } else {
          setIsWinner(false);
        }
      } catch (error) {
        console.error("Error in loadContractData:", error);
      }
    };

    loadBlockchainData();
    loadContractData();
  }, [currentAccount]);

  // Write Transactions
  const enterLottery = async () => {
    if (!contractInstance) return;
    try {
      const amountToSend = ethers.parseEther("0.1"); // v6 parseEther
      const tx = await contractInstance.enter({ value: amountToSend });
      await tx.wait();
      console.log("Entered lottery!");
    } catch (err) {
      console.error("Error entering lottery:", err);
    }
  };

  const claimPrize = async () => {
    if (!contractInstance) return;
    try {
      const tx = await contractInstance.claimPrize();
      await tx.wait();
      console.log("Prize claimed!");
    } catch (err) {
      console.error("Error claiming prize:", err);
    }
  };

  return (
    <div className="container">
      <h1>Lottery Page</h1>
      <div className="button-container">
        {status ? (
          isWinner ? (
            <button className="enter-button" onClick={claimPrize}>
              Claim Prize
            </button>
          ) : (
            <p>You are not the winner</p>
          )
        ) : (
          <button className="enter-button" onClick={enterLottery}>
            Enter Lottery
          </button>
        )}
      </div>
    </div>
  );
}

export default Home;
